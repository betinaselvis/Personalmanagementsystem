import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class PersonalManagementSystemUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Connection conn;

    public PersonalManagementSystemUI() {
        conn = DatabaseConnection.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            System.out.println("Database connected successfully!");
        }

        setTitle("Personal Management System");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPage(), "Login");
        mainPanel.add(createMainMenu(), "MainMenu");
        mainPanel.add(createContactsPage(), "Contacts");
        mainPanel.add(createTasksPage(), "Tasks");
        mainPanel.add(createCalendarPage(), "Calendar");
        

        add(mainPanel);
        setVisible(true);
    }
    private boolean authenticateUser(String username, String password) {
    try {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
        stmt.setString(1, username);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();
        return rs.next();
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

private boolean registerUser(String username, String password) {
    try {
        PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
        checkStmt.setString(1, username);
        ResultSet rs = checkStmt.executeQuery();
        if (rs.next()) {
            return false;
        }

        PreparedStatement insertStmt = conn.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)");
        insertStmt.setString(1, username);
        insertStmt.setString(2, password);
        insertStmt.executeUpdate();
        return true;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

    

    private JPanel createMainMenu() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        JButton btnContacts = new JButton("Manage Contacts");
        JButton btnTasks = new JButton("Manage Tasks");
        JButton btnCalendar = new JButton("Calendar & Schedule");
        
        btnContacts.addActionListener(e -> cardLayout.show(mainPanel, "Contacts"));
        btnTasks.addActionListener(e -> cardLayout.show(mainPanel, "Tasks"));
        btnCalendar.addActionListener(e -> cardLayout.show(mainPanel, "Calendar"));
        
        panel.add(btnContacts);
        panel.add(btnTasks);
        panel.add(btnCalendar);
        return panel;
    }

    private JPanel createContactsPage() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        JButton btnAdd = new JButton("Add Contact");
        JButton btnView = new JButton("View Contacts");
        JButton btnBack = new JButton("Back");

        btnBack.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));

        btnAdd.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Enter Name:");
            String phone = JOptionPane.showInputDialog("Enter Phone Number:");
            try {
                PreparedStatement stmt = conn.prepareStatement("INSERT INTO contacts (name, phone) VALUES (?, ?)");
                stmt.setString(1, name);
                stmt.setString(2, phone);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Contact Added!");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        btnView.addActionListener(e -> {
            try {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM contacts");

                if (!rs.isBeforeFirst()) { 
                    JOptionPane.showMessageDialog(null, "No contacts found!", "Info", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                JTable table = new JTable(buildTableModel(rs));
                JOptionPane.showMessageDialog(null, new JScrollPane(table));
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching contacts!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(btnAdd);
        panel.add(btnView);
        panel.add(btnBack);
        return panel;
    }

    private JPanel createTasksPage() {
    JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
    JButton btnAdd = new JButton("Add Task");
    JButton btnView = new JButton("View Tasks");
    JButton btnDelete = new JButton("Delete Task");
    JButton btnBack = new JButton("Back");

    btnBack.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));

    btnAdd.addActionListener(e -> {
        String taskName = JOptionPane.showInputDialog("Enter Task Name:");
        String taskDate = JOptionPane.showInputDialog("Enter Task Date (YYYY-MM-DD):");
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO tasks (task_name, task_date) VALUES (?, ?)");
            stmt.setString(1, taskName);
            stmt.setString(2, taskDate);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Task Added!");

            // Refresh calendar after adding a task
            updateCalendarView();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    });

    btnView.addActionListener(e -> {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM tasks");

            JTable table = new JTable(buildTableModel(rs));
            JScrollPane scrollPane = new JScrollPane(table);

            JDialog dialog = new JDialog();
            dialog.setTitle("Tasks List");
            dialog.setSize(400, 300);
            dialog.add(scrollPane);
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    });

    btnDelete.addActionListener(e -> {
        String taskId = JOptionPane.showInputDialog("Enter Task ID to delete:");
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM tasks WHERE id = ?");
            stmt.setInt(1, Integer.parseInt(taskId));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Task Deleted!");

            // Refresh calendar after deleting a task
            updateCalendarView();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    });

    panel.add(btnAdd);
    panel.add(btnView);
    panel.add(btnDelete);
    panel.add(btnBack);
    return panel;
}

    private JPanel calendarPanel;
private JTextArea calendarTextArea;

private JPanel createCalendarPage() {
    calendarPanel = new JPanel(new BorderLayout());
    JLabel label = new JLabel("Calendar & Schedule", SwingConstants.CENTER);
    calendarTextArea = new JTextArea();
    calendarTextArea.setEditable(false);

    JScrollPane scrollPane = new JScrollPane(calendarTextArea);
    JButton btnBack = new JButton("Back");

    btnBack.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));

    JPanel bottomPanel = new JPanel();
    bottomPanel.add(btnBack);

    calendarPanel.add(label, BorderLayout.NORTH);
    calendarPanel.add(scrollPane, BorderLayout.CENTER);
    calendarPanel.add(bottomPanel, BorderLayout.SOUTH);

    updateCalendarView();  // Load tasks when switching to calendar page
    return calendarPanel;
}



    private DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);
    }

   private JPanel createLoginPage() {
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.WEST;

    JLabel titleLabel = new JLabel("Personal Management System");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    panel.add(titleLabel, gbc);

    gbc.gridy++;
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.WEST;
    panel.add(new JLabel("Username:"), gbc);

    gbc.gridx = 1;
    JTextField usernameField = new JTextField(15);
    panel.add(usernameField, gbc);

    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(new JLabel("Password:"), gbc);

    gbc.gridx = 1;
    JPasswordField passwordField = new JPasswordField(15);
    panel.add(passwordField, gbc);

    gbc.gridx = 0;
    gbc.gridy++;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    
    JButton loginButton = new JButton("Login");
    JButton signUpButton = new JButton("Sign Up");

    // LOGIN BUTTON ACTION
    loginButton.addActionListener(e -> {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (authenticateUser(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            cardLayout.show(mainPanel, "MainMenu");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Username or Password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    // SIGN UP BUTTON ACTION
    signUpButton.addActionListener(e -> {
        JTextField newUserField = new JTextField();
        JPasswordField newPasswordField = new JPasswordField();
        JPasswordField confirmPasswordField = new JPasswordField();

        Object[] message = {
            "Username:", newUserField,
            "Password:", newPasswordField,
            "Confirm Password:", confirmPasswordField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Sign Up", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String newUsername = newUserField.getText();
            String newPassword = new String(newPasswordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            if (newPassword.equals(confirmPassword)) {
                if (registerUser(newUsername, newPassword)) {
                    JOptionPane.showMessageDialog(this, "Sign Up Successful! You can now log in.");
                } else {
                    JOptionPane.showMessageDialog(this, "User already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(loginButton);
    buttonPanel.add(signUpButton);

    gbc.gridy++;
    panel.add(buttonPanel, gbc);

    return panel;
}

    private void updateCalendarView() {
        StringBuilder calendarContent = new StringBuilder("Scheduled Tasks:\n\n");
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT task_name, task_date FROM tasks ORDER BY task_date");
            while (rs.next()) {
                calendarContent.append(rs.getString("task_date"))
                               .append(" - ")
                               .append(rs.getString("task_name"))
                               .append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            calendarContent.append("Error loading tasks.");
        }
        calendarTextArea.setText(calendarContent.toString());
    }
    public static void main(String[] args) {
        new PersonalManagementSystemUI();
    }
}
