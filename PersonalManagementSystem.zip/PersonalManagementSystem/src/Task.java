import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Task {
    public void addTask(String title, String description) {
        String sql = "INSERT INTO tasks (title, description) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) {
                System.out.println("Database connection failed!");
                return;
            }
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.executeUpdate();
            System.out.println("Task added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> getTasks() {
        List<String> tasks = new ArrayList<>();
        String sql = "SELECT id, title, description FROM tasks";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (conn == null) {
                System.out.println("Database connection failed!");
                return tasks;
            }
            while (rs.next()) {
                tasks.add(rs.getInt("id") + " - " + rs.getString("title") + " - " + rs.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    public void updateTask(int id, String title, String description) {
        String sql = "UPDATE tasks SET title = ?, description = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) {
                System.out.println("Database connection failed!");
                return;
            }
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            System.out.println("Task updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteTask(int id) {
        String sql = "DELETE FROM tasks WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) {
                System.out.println("Database connection failed!");
                return;
            }
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Task deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
