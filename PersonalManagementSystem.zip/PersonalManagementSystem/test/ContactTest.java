/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Betina
 */
public class ContactTest {
    
    public ContactTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addContact method, of class Contact.
     */
    @Test
    public void testAddContact() {
        System.out.println("addContact");
        String name = "";
        String phone = "";
        Contact instance = new Contact();
        instance.addContact(name, phone);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getContacts method, of class Contact.
     */
    @Test
    public void testGetContacts() {
        System.out.println("getContacts");
        Contact instance = new Contact();
        List<String> expResult = null;
        List<String> result = instance.getContacts();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateContact method, of class Contact.
     */
    @Test
    public void testUpdateContact() {
        System.out.println("updateContact");
        int id = 0;
        String name = "";
        String phone = "";
        Contact instance = new Contact();
        instance.updateContact(id, name, phone);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteContact method, of class Contact.
     */
    @Test
    public void testDeleteContact() {
        System.out.println("deleteContact");
        int id = 0;
        Contact instance = new Contact();
        instance.deleteContact(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
